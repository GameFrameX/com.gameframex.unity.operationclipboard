package com.alianhome.clipboardoperation;

import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerNativeActivity;

public class MainActivity extends UnityPlayerNativeActivity {

	private final static String ObjectName = "BlankOperationClipboard";
	private final static String ReceiveDataFunctionName = "ReceiveDataCallBack";

	/**
	 * ��ȡճ�����ֵ
	 * 
	 * @param activity
	 *            Unity ��Activity
	 * @return ����ճ�����е�ֵ
	 */
	public static String GetClipBoard() {

		ClipboardManager clipboard = (ClipboardManager) UnityPlayer.currentActivity.getSystemService(Context.CLIPBOARD_SERVICE);
		return clipboard.getText().toString();
		// ���ͽ�����Ϣ��unity
		// UnityPlayer.UnitySendMessage(ObjectName, ReceiveDataFunctionName,
		// clipboard.getText().toString());

	}

	/**
	 * ����ճ���������
	 * 
	 * @param activity
	 *            Unity��Activity
	 * @param text
	 *            ����
	 */
	public static void SetClipBoard(final String text) {
		UnityPlayer.currentActivity.runOnUiThread(new Runnable() {
			@Override
			public void run() {
				ClipboardManager clipboard = (ClipboardManager) UnityPlayer.currentActivity.getSystemService(Context.CLIPBOARD_SERVICE);
				clipboard.setText(text);
			}
		});
	}
}
