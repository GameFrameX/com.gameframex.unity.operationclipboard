package com.alianhome.operationclipboard;

import android.content.ClipboardManager;

import com.unity3d.player.*;

public class MainActivity extends UnityPlayerActivity {
	public static String GetClipBoard() {
		ClipboardManager clipboard = (ClipboardManager) UnityPlayer.currentActivity
				.getSystemService("clipboard");
		return clipboard.getText().toString();
	}

	public static void SetClipBoard(final String text) {
		UnityPlayer.currentActivity.runOnUiThread(new Runnable() {
			public void run() {
				ClipboardManager clipboard = (ClipboardManager) UnityPlayer.currentActivity
						.getSystemService("clipboard");
				clipboard.setText(text);
			}
		});
	}
}
